<footer class="main-footer">
  <div class="pull-right hidden-xs">
  </div>
  <strong>Copyright 2021 &copy; Construction Project Employee Attendance and Project Materials Cost Monitoring System </strong>
</footer>