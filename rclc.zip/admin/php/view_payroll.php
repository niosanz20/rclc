<?php
include '../includes/conn.php';

if (isset($_POST['empID'])) {
  $empID = $_POST['empID'];
  $sql = "SELECT *, employees.id AS empid FROM employees LEFT JOIN position ON position.id=employees.position_id LEFT JOIN schedules ON schedules.id=employees.schedule_id WHERE employees.employee_id='$empID'";
  $query = $conn->query($sql);
  $row = $query->fetch_assoc();

  //SEKSI PATS
  $sqlCutoff = "SELECT * FROM cutoff ORDER BY end_date DESC";
  $resultCutoff = mysqli_query($conn, $sqlCutoff);

  // $sqlCutoff = "SELECT * FROM cashadvance as ca, project_materials_log as p WHERE ca.employee_id = p.name AND c.employee_id = '$empID'";
  // $resultCutoff = mysqli_query($conn, $sqlCutoff);
  //end of SEKSI PATS

?>
  <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <div class="panel" id="payrollSummary">
    <div class="box-body">
      <div class="row">
        <!-- <h4><span class="glyphicon glyphicon-file"></span>Payroll Summary for <strong><?php echo $row['firstname'] . ' ' . $row['lastname']; ?></strong> <span> #<?php echo $empID ?></span></h4>  -->
      </div>
      <table id="example4" class="table table-bordered" style=" width:100%">
        <thead>
          <th>Ref. ID</th>
          <th style="width: 100%">Cut-Off Date</th>
          <th>Gross Income</th>
          <th>OT</th>
          <th>Cash Advance</th>
          <th>Cost of Damage Materials</th>
          <th>SSS</th>
          <th>PhilHealth</th>
          <th>Pag-ibig</th>
          <th>Actions</th>
        </thead>
        <tbody>
          <!--
                Position - Employee table link to Position table
                Total_Hr - sum of num_hr in attendance table
                Cash Advance - cashadvance table
                Cost of Damage Materials - price sa project_materials_log
                Deduction -  (deductions table)
                OT - Attendance table
              -->


          <!--  //SEKSI PATS -->
          <?php

          while ($rowCutoff = mysqli_fetch_array($resultCutoff)) :

            $cutoff_id = $rowCutoff['cutoff_id'];
            // $employee_id = $rowCutoff['employee_id']; 
            $new_start_date = $rowCutoff['start_date'];
            $new_end_date = $rowCutoff['end_date'];
            $start_date = date("M j Y", strtotime($rowCutoff['start_date']));
            $end_date = date("M j Y", strtotime($rowCutoff['end_date']));
            // $sss = $rowCutoff['sss'];
            // $philhealth = $rowCutoff['philhealth'];
            // $pagibig = $rowCutoff['pagibig'];

            $sqlAdvanceDam = "SELECT * FROM cashadvance as ca, project_materials_log as p WHERE ca.employee_id = p.name AND ca.employee_id = '$empID'";
            $resultAdvanceDam = mysqli_query($conn, $sqlAdvanceDam);
            $rowAdvanceDam = mysqli_fetch_assoc($resultAdvanceDam);

            $amount = $rowAdvanceDam['amount'];  //cash advance
            $price = $rowAdvanceDam['price'];   //cost of damage

            //gross
            $sqlGross = "SELECT SUM(num_hr) as total_numhr, rate FROM attendance as a, position as p, employees as e WHERE a.employee_id = e.employee_id AND p.id = e.position_id AND e.employee_id = '$empID' AND a.date BETWEEN '$new_start_date' AND '$new_end_date'";
            $resultGross = mysqli_query($conn, $sqlGross);
            $rowGross = mysqli_fetch_assoc($resultGross);

            $gross = $rowGross['rate'] * $rowGross['total_numhr'];

            //OT
            $sqlOT = "SELECT SUM(amount) as total_amount  from overtime where date_overtime BETWEEN '$new_start_date' AND '$new_end_date' AND employee_id = '$empID' AND ot_status = 'Approved'";
            $resultOT = mysqli_query($conn, $sqlOT);
            $rowOT = mysqli_fetch_assoc($resultOT);

            if ($rowOT['total_amount'] == NULL)
              $rowOT['total_amount'] = 0;

            //cash advance
            $sqlCashAd = "SELECT SUM(amount) as total_amount  from cashadvance where date_advance BETWEEN '$new_start_date' AND '$new_end_date' AND employee_id = '$empID'";
            $resultCashAd = mysqli_query($conn, $sqlCashAd);
            $rowCashAd = mysqli_fetch_assoc($resultCashAd);

            if ($rowCashAd['total_amount'] == NULL)
              $rowCashAd['total_amount'] = 0;

            //damage
            $sqlDamage = "SELECT SUM(price) as total_price  from project_materials_log where date BETWEEN '$new_start_date' AND '$new_end_date' AND name = '$empID'";
            $resultDamage = mysqli_query($conn, $sqlDamage);
            $rowDamage = mysqli_fetch_assoc($resultDamage);

            if ($rowDamage['total_price'] == NULL)
              $rowDamage['total_price'] = 0;

            //sss
            if ($gross < 3250)
              $sss = 135;
            else if (3749.99 >= $gross && $gross > 3250)
              $sss = 157.50;
            else if (4249.99 >= $gross && $gross > 3750)
              $sss = 180;
            else if (4749.99 >= $gross && $gross > 4250)
              $sss = 202.5;
            else if (5249.99 >= $gross && $gross > 4750)
              $sss = 225;
            else if (5749.99 >= $gross && $gross > 5250)
              $sss = 247.5;
            else if (6249.99 >= $gross && $gross > 5750)
              $sss = 270;
            else if (6749.99 >= $gross && $gross > 6250)
              $sss = 292.5;
            else if (7249.99 >= $gross && $gross > 6750)
              $sss = 315;
            else if (7749.99 >= $gross && $gross > 7250)
              $sss = 337.5;
            else if (8249.99 >= $gross && $gross > 7750)
              $sss = 360;
            else if (8749.99 >= $gross && $gross > 8250)
              $sss = 382.5;
            else if (9249.99 >= $gross && $gross > 8750)
              $sss = 405;
            else if (9749.99 >= $gross && $gross > 9250)
              $sss = 427.5;
            else if (10249.99 >= $gross && $gross > 9750)
              $sss = 450;

            //philhealth
            $philhealth = $gross * 0.035 / 2;
            $pagibig = 50;

          ?>

            <tr>
              <td><?php echo $cutoff_id; ?></td>
              <td style="width: 100%"><?php echo $start_date . " - " . $end_date; ?></td>
              <td>₱ <?php echo number_format($gross); ?></td>
              <td>₱ <?php echo $rowOT['total_amount']; ?></td>
              <td>₱ <?php echo $rowCashAd['total_amount']; ?></td>
              <td>₱ <?php echo $rowDamage['total_price']; ?></td>
              <td>₱ <?php echo number_format($sss); ?></td>
              <td>₱ <?php echo number_format($philhealth); ?></td>
              <td>₱ <?php echo number_format($pagibig); ?></td>
              <td>
                <button type="submit" class="viewPayrollDetails btn btn-success btn-sm btn-flat" id="<?php echo $empID ?>"><span class="glyphicon glyphicon-file"></span> Print</button>
              </td>
            </tr>


          <?php
            //insert to yeartodate
            $sqlYTD = "SELECT * from yeartodate WHERE employee_id = '$empID'";
            $resultYTD = mysqli_query($conn, $sqlYTD);
            $rowYTD = mysqli_fetch_assoc($resultYTD);

            $philhealth = $rowYTD['philhealth'] + $philhealth;
            $pagibig = $rowYTD['pagibig'] + $pagibig;
            $sss = $rowYTD['sss'] + $sss;
            $gross = $rowYTD['gross_income'] + $gross;

            $sqlYear = "UPDATE yeartodate set
                    philhealth = '$philhealth',
                    pagibig = '$pagibig',
                    sss = '$sss',
                    gross_income = '$gross'
                    WHERE employee_id = '$empID'";

            $conn->query($sqlYear);

          endwhile;

          ?>

          <!-- //end SEKSI PATS -->

        </tbody>
      </table>
    </div>
  </div>


  <!---->
  <!-- PRINT -->
  <?php
  $sqlpayslip = "SELECT *, employees.id AS empid FROM employees LEFT JOIN position ON position.id=employees.position_id LEFT JOIN schedules ON schedules.id=employees.schedule_id WHERE employees.employee_id='$empID'";
  $querypayslip = $conn->query($sqlpayslip);
  $rowpaylsip = $querypayslip->fetch_assoc();
  ?>
  <div class="panel" id="printout" style="visibility: hidden;">
    <div class="row">
      <table class="greyGridTable">
        <thead>
          <tr>
            <th colspan="6">RC Llaguno Construction</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td width="20%" align="left"><b>NAME</b></td>
            <td width="10%" align="left">: <?php echo $rowpaylsip['firstname'] . ' ' . $rowpaylsip['lastname'] ?></td>
            <td width="10%"></td>
            <td width="20%" align="left"><b>TAX STATUS</b></td>
            <td width="10%" align="left">: S</td>
          </tr>
          <tr>
            <td width="20%" align="left"><b>PAYROLL DATE</b></td>
            <td width="10%" align="left">: <?php echo date_format(date_create(date('m/d/Y')), "M. d, Y") ?></td>
            <td width="10%"></td>
            <td width="20%" align="left"><b>TIN</b></td>
            <td width="10%" align="left">: 52341234</td>
          </tr>
          <tr>
            <td width="20%" align="left"><b>DATE COVERED</b></td>
            <td width="20%" align="left">: (<?php echo date_format(date_create(date('m/d/Y', strtotime('-30 day'))), "M. d, Y") . ' - ' . date_format(date_create(date('m/d/Y')), "M. d, Y") ?>)</td>
            <td width="10%"></td>
            <td width="20%" align="left"><b>SSS NO.</b></td>
            <td width="10%" align="left">: 52341234</td>
          </tr>
          <tr>
            <td width="20%" align="left"><b>POSITION</b></td>
            <td width="10%" align="left">: <?php echo $rowpaylsip['description'] ?></td>
            <td width="10%"></td>
            <td width="20%" align="left"><b>PHILHEALTH NO.</b></td>
            <td width="10%" align="left">: 52341234</td>
          </tr>
          <tr>
            <td width="20%" align="left"></td>
            <td width="10%" align="left"></td>
            <td width="10%"></td>
            <td width="20%" align="left"><b>HDMIF NO.</b></td>
            <td width="10%" align="left">: 52341234</td>
          </tr>
        </tbody>
      </table>
      <table class="greyGridTable" id="secondTable">
        <thead>
          <tr>
            <th colspan="2">COMPENSATION
            </th>
            <th colspan="2">DEDUCTIONS
            </th>
            <th colspan="2">YEAR-TO-DATE</th>
          </tr>
        </thead>
        <tfoot>
          <tr>
            <th>TOTAL <br> COMPENSATION
            </th>
            <th>₱ 100,000</th>
            <th>TOTAL <br> DEDUCTIONS
            </th>
            <th>₱ 100,000</th>
            <th>NET PAY</th>
            <th>₱ 100,000</th>
          </tr>
        </tfoot>
        <tbody>
          <tr>
            <td width="20%" align="left"><b>RATE</b></td>
            <td width="10%" align="right">100</td>
            <td width="20%" align="left"><b>CASH ADVANCE</b></td>
            <td width="10%" align="right">100</td>
            <td width="20%" align="left"><b>TAX</b></td>
            <td width="10%" align="right">100</td>
          </tr>
          <tr>
            <td width="20%" align="left"><b>TOTAL HOURS</b></td>
            <td width="10%" align="right">100</td>
            <td width="20%" align="left"><b>SSS</b></td>
            <td width="10%" align="right">100</td>
            <td width="20%" align="left"><b>SSS</b></td>
            <td width="10%" align="right">100</td>
          </tr>
          <tr>
            <td width="20%" align="left"><b>BASIC</b></td>
            <td width="10%" align="right">100</td>
            <td width="20%" align="left"><b>PHILHEALTH</b></td>
            <td width="10%" align="right">100</td>
            <td width="20%" align="left"><b>PHILHEALTH</b></td>
            <td width="10%" align="right">100</td>
          </tr>
          <tr>
            <td width="20%" align="left"><b>OT (10 hrs)</b></td>
            <td width="10%" align="right">100</td>
            <td width="20%" align="left"><b>HDMIF</b></td>
            <td width="10%" align="right">100</td>
            <td width="20%" align="left"><b>HDMIF</b></td>
            <td width="10%" align="right">100</td>
          </tr>
          <tr>
            <td width="20%" align="left"><b></b></td>
            <td width="10%" align="right"></td>
            <td width="20%" align="left"><b>MATERIAL LOST</b></td>
            <td width="10%" align="right">100</td>
            <td width="20%" align="left"><b>GROSS INCOME</b></td>
            <td width="10%" align="right">100</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="legend">
      <table style="border:none">
        <thead>
          <th colspan="4">LEGEND</th>
        </thead>
        <tbody>
          <tr>
            <td>LH -</td>
            <td>Legal Holiday</td>
            <td>OT -</td>
            <td>Overtime</td>
          </tr>
          <tr>
            <td>SH -</td>
            <td>Special Holiday &nbsp</td>
            <td>RD -</td>
            <td>Rest Day</td>
          </tr>
          <tr>
            <td>DH -</td>
            <td>Double Holiday</td>
            <td></td>
            <td></td>
          </tr>

        </tbody>
      </table>
    </div>
  </div>
  <!-- DataTables -->
  <script src="../bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="../bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
  <script>
    $(function() {
      $('#example4').DataTable({
        "order": [
          [0, "desc"]
        ],
        responsive: true,
        'paging': true,
        'lengthChange': false,
        pageLength: 5,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': false
      })
    })
  </script>
<?php } ?>